# Build and Deploy movie app with React & Redux | Mobile Responsive

![Alt text](thumnail.png?raw=true "Title")

REACT_APP_ACCESS_TOKEN = < The Movie Database Access Token >

Image : https://drive.google.com/drive/folders/17fx2Gwpq3VzzYd0ToZI9bK1go2hVKXfr?usp=sharing
